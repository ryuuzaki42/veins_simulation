//###################################################################
//                        To compile:
// g++ -std=c++0x -Wall -o script_conversor2.out script_conversor2.cc
//###################################################################

#include <iostream>
#include <fstream>
#include <unordered_map>

using namespace std;

int main() {
    string fileInput;
    cout << "\nEnter file name: ";
    cin >> fileInput;
    cout << "File name: \"" <<  fileInput << "\"";

    if (fileInput.size() < 10) {
        cout << "Error: Need pass the file name\n\n";
        exit(1);
    }

    string fileOutput = fileInput.substr(0, fileInput.size() - 8) + "_final.rou.xml";

    FILE* fptr = freopen(fileInput.c_str(), "r", stdin); //Arquivo de entrada gerado com script randomTrips.py
    if (fptr != NULL) {
        fclose(fptr);
        cout << " - File exists\n\n";
        freopen(fileInput.c_str(), "r", stdin); //Arquivo de entrada gerado com script randomTrips.py
    } else {
        cout << " - File doesnt exist\n\n";
        exit(1);
    }

    ofstream output;
    output.open(fileOutput); //Arquivo que será criado com todas rotas

    //Escrita da definição do tipo de veículo no arquivo de saída
    output << "<routes>\n    <vType id=\"vtype0\" accel=\"3\" decel=\"5\" sigma=\"0.5\" length=\"2.5\" minGap=\"2.5\" maxSpeed=\"15\" color=\"1,1,0\"/>\n\n";

    int count = 1;
    int countRoutes = 80;
    string route, line;
    unordered_map<string, int> routes;
    unordered_map<string, int>::iterator it;
    bool print = false;
    int posEqual, posSpace;

    cout << "Por favor espere, gerando rotas2...\n\n";

    while (getline(cin, line)) {
        //cout << "line: " << line << "\n";
        if (line.compare(0,15,"        <route ") == 0) { // Edita cada linha do arquivo de entrada que representa rotas
            string to = "    <route id=\"";
            to +="route" + to_string(count);
            to +="\"";
            to += line.substr(14) + "\n";

            posEqual = line.find('=', 0);
            posEqual += 2; // + 2 to ="
            posSpace = line.find(' ', posEqual);

            route = line.substr(posEqual, (posSpace - posEqual)); // Pega o primeiro ponto (ponto de partida)
            cout << "\nposEqual: " << posEqual << " posSpace: " << posSpace << " ID: " << route << "\n";

            it = routes.find(route);
            if (it != routes.end()) { // Testa se ele já foi inserido ou existe
                if (it->second < countRoutes) {
                    it->second += 1; // Incrementa a quantidade desta rota
                    print = true;
                }
            } else {
                routes.insert(make_pair(route, 1));
                print = true;
            }

            if (print) {
                output << to; //Escrita da rota no arquivo de saída
                cout << to; //Imprime rotas geradas no terminal
                count++;
                print = false;
            }
        }
    }
    output << endl;

    output << "</routes>"; //Finalização do arquivo de saída
    output.close();
    cout << endl;

    int routesCount = 0;
    for (it = routes.begin(); it != routes.end(); it++) {
        if (it->second == 80) {
            cout << it->first << " " << it->second << endl;
        } else {
            cout <<"    " << it->first << " " << it->second << endl;
        }
        routesCount += it->second;
    }

    cout << endl << "Sum start points: " << routes.size() << endl;
    cout << "Sum routes: " << routesCount << endl << endl;
    cout << "Routes saved: " << fileOutput << "\n\n";
    return 0;
}
